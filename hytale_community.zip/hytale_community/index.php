<?php /** @var $this \Ilch\Layout\Frontend */ 

$projectName    = $this->getLayoutSetting('project_name') ?: 'HYTALE GAMING';
$accentColor    = $this->getLayoutSetting('color') ?: '#00f2ff';
$headerHeight   = (int)($this->getLayoutSetting('hida_height') ?: 650);
$layoutUrl      = $this->getLayoutUrl();

$pageTitle = property_exists($this, 'title') ? $this->title : 'DATABASE_STREAM';

// Slider Bilder aus Admin-Config laden
$img1 = $this->getBaseUrl($this->getLayoutSetting('slider_img_1')) ?: $layoutUrl . '/img/header_bg.jpg';
$img2 = $this->getBaseUrl($this->getLayoutSetting('slider_img_2')) ?: $img1;
$img3 = $this->getBaseUrl($this->getLayoutSetting('slider_img_3')) ?: $img1;
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= $this->getHeader() ?>
    
    <link href="<?= $layoutUrl ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= $layoutUrl ?>/css/aos.css" rel="stylesheet">
    <link href="<?= $layoutUrl ?>/css/all.min.css" rel="stylesheet">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Lexend+Exa:wght@400;700;900&family=Rajdhani:wght@500;600;700&display=swap');

        :root { 
            --accent: <?= $accentColor ?>; 
            --glass: rgba(7, 10, 15, 0.5);
            --huawei-glow: 0 0 25px var(--accent), 0 0 50px rgba(0, 242, 255, 0.2);
        }

        /* --- GLOBAL --- */
        ::-webkit-scrollbar { width: 10px; background: #000; }
        ::-webkit-scrollbar-thumb { background: var(--accent); border: 2px solid #000; }
        
        body { 
            background: #000 url('<?= $layoutUrl ?>/img/bg.jpg') fixed no-repeat center top/cover;
            color: #fff; font-family: 'Rajdhani', sans-serif; margin: 0; padding: 0; overflow-x: hidden;
        }

        a { color: var(--accent) !important; text-decoration: none !important; transition: 0.3s; }
        a:hover { color: #fff !important; text-shadow: 0 0 10px var(--accent); }

        /* --- NAVIGATION FX (DROP-LINES) --- */
        .master-nav { min-height: 110px; background: var(--glass); border-bottom: 3px solid var(--accent); position: sticky; top: 0; z-index: 10000; display: flex; align-items: center; backdrop-filter: blur(10px); }
        .nav-container { display: flex; width: 100%; justify-content: space-between; align-items: center; padding: 0 5%; }
        .top-menu-list ul { display: flex !important; flex-direction: row !important; list-style: none; gap: 35px; margin: 0; padding: 0; }
        .top-menu-list a { font-family: 'Lexend Exa' !important; font-size: 0.85rem; color: #fff !important; text-transform: uppercase; position: relative; }
        
        .top-menu-list a::before, .top-menu-list a::after {
            content: ''; position: absolute; width: 2px; height: 0; background: var(--accent); 
            transition: 0.4s ease; top: -10px; opacity: 0; box-shadow: 0 0 10px var(--accent);
        }
        .top-menu-list a::before { left: -12px; } .top-menu-list a::after { right: -12px; }
        .top-menu-list a:hover::before, .top-menu-list a:hover::after { height: 40px; opacity: 1; top: 0; }

        .mobile-toggle { display: none; color: var(--accent); font-size: 1.8rem; cursor: pointer; }
        @media (max-width: 991px) {
            .mobile-toggle { display: block; }
            .top-menu-list { display: none; position: absolute; top: 110px; left: 0; width: 100%; background: var(--glass); border-bottom: 2px solid var(--accent); padding: 20px; z-index: 10001; }
            .top-menu-list.show { display: block; }
            .top-menu-list ul { flex-direction: column !important; gap: 10px; }
        }

        /* --- LOGIN BUTTON HEADER (SWEEP FX) --- */
        .btn-login-header {
            color: var(--accent) !important; border: 2px solid var(--accent) !important;
            font-family: 'Lexend Exa'; cursor: pointer; position: relative; overflow: hidden;
            background: transparent; transition: 0.3s;
        }
        .btn-login-header::after {
            content: ''; position: absolute; top: 0; left: -100%; width: 50%; height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
            transform: skewX(-25deg); transition: 0.6s;
        }
        .btn-login-header:hover::after { left: 150%; }
        .btn-login-header:hover { box-shadow: var(--huawei-glow); background: rgba(0, 242, 255, 0.05); }

        /* --- SLIDER ENGINE (MULTIPLE IMAGES) --- */
        .slider-backramp { height: <?= $headerHeight ?>px; width: 100%; position: relative; overflow: hidden; background: #000; display: flex; align-items: center; justify-content: center; }
        
        .slide-item { 
            position: absolute; inset: 0; width: 100%; height: 100%; 
            background-size: cover; background-position: center; 
            opacity: 0; transition: opacity 2s ease-in-out; 
            transform: scale(1.1); 
        }

        .slide-item.active { 
            opacity: 0.45; 
            transform: scale(1.0); 
            transition: opacity 2s ease-in-out, transform 8s linear; 
        }
        
        .brand-master-title { text-align: center; z-index: 10; font-family: 'Lexend Exa' !important; text-transform: uppercase; }
        .brand-master-title h1 { font-size: 4.5rem; font-weight: 900; color: #fff; text-shadow: 0 0 30px var(--accent); margin: 0; }
        .brand-master-title .sub-line { display: block; font-size: 1.2rem; color: var(--accent); letter-spacing: 12px; margin-top: -5px; margin-left: 40px; opacity: 0.9; }

        /* --- BOXEN & LOGIN FIX --- */
        .hytale-card { background: var(--glass) !important; margin-bottom: 60px !important; position: relative !important; border: 1px solid rgba(255,255,255,0.05) !important; overflow: hidden !important; backdrop-filter: blur(10px); transition: 0.4s; }
        .hytale-card:hover { box-shadow: var(--huawei-glow) !important; transform: translateY(-5px); }
        .card-header { background: rgba(255,255,255,0.02) !important; padding: 20px 25px !important; border-bottom: 3px solid var(--accent) !important; font-family: 'Lexend Exa' !important; color: #fff !important; text-transform: uppercase !important; }

        .ilch_user_login .form-group { position: relative; margin-bottom: 20px !important; }
        .ilch_user_login .form-group i { display: none !important; }
        .ilch_user_login .form-group::before {
            font-family: "Font Awesome 6 Free" !important; font-weight: 900 !important; 
            position: absolute; left: 15px; top: 50%; transform: translateY(-50%); 
            color: var(--accent) !important; z-index: 20;
        }
        .ilch_user_login .form-group:nth-child(1)::before { content: "\f007"; } 
        .ilch_user_login .form-group:nth-child(2)::before { content: "\f023"; } 

        .ilch_user_login input, select, .form-control { 
            padding-left: 45px !important; background: rgba(0,0,0,0.8) !important; 
            border: 1px solid var(--accent) !important; color: #fff !important; border-radius: 0 !important; 
        }
        .ilch_user_login button { width: 100% !important; background: var(--accent) !important; color: #000 !important; font-family: 'Lexend Exa' !important; font-weight: 900; border: none !important; padding: 12px !important; margin-top: 15px; }

        /* --- TRENNLINIE ANIMIERT --- */
        .section-separator { height: 12px; background: rgba(20, 25, 30, 0.95); border-bottom: 3px solid var(--accent); position: relative; overflow: hidden; z-index: 100; margin-top: -12px; }
        .section-separator::after { content: ''; position: absolute; top: 95%; left: -100%; width: 25%; height: 2px; background: linear-gradient(90deg, transparent, var(--accent), #fff, var(--accent), transparent); box-shadow: 0 0 15px var(--accent); animation: blitz-run 4s infinite linear; transform: translateY(-50%); }
        @keyframes blitz-run { 0% { left: -100%; } 100% { left: 100%; } }

        /* Snakes */
        .snake-top, .snake-bottom { position: absolute; width: 100%; height: 3px; z-index: 100; pointer-events: none; }
        .snake-top { top: 0; left: -100%; background: linear-gradient(90deg, transparent, var(--accent), #fff, var(--accent), transparent); animation: s-top 3.5s infinite linear; }
        .snake-bottom { bottom: 0; right: -100%; background: linear-gradient(90deg, transparent, #fff, var(--accent), #fff, transparent); animation: s-bottom 3.5s infinite linear; }
        @keyframes s-top { 0% { left: -100%; } 100% { left: 100%; } }
        @keyframes s-bottom { 0% { right: -100%; } 100% { right: 100%; } }

        /* --- FOOTER --- */
        .master-footer { background: rgba(5, 7, 10, 0.98); border-top: 3px solid var(--accent); padding: 60px 0 30px; position: relative; margin-top: 100px; }
        .footer-logo { font-family: 'Lexend Exa'; font-weight: 900; font-size: 1.5rem; letter-spacing: 2px; }
    </style>
</head>
<body id="top">

    <nav class="master-nav">
        <div class="nav-container">
            <a href="<?= $this->getUrl() ?>" class="brand-stacked text-decoration-none">
                <span style="color:#fff; font-family:'Lexend Exa'; font-weight:900; font-size:1.8rem;">HYTALE</span><br>
                <span style="color:var(--accent); font-family:'Lexend Exa'; font-size:0.6rem; letter-spacing:4px;">MULTI GAMING DESIGN</span>
            </a>
            
            <div class="mobile-toggle" onclick="$('.top-menu-list').toggleClass('show')">
                <i class="fa-solid fa-bars"></i>
            </div>

            <div class="top-menu-list">
                <?= $this->getMenu(3, '<ul>%c</ul>') ?>
            </div>
            
            <div onclick="document.getElementById('loginPopup').style.display='flex'" class="btn btn-login-header rounded-0 px-4 py-2 d-none d-lg-block">LOGIN</div>
        </div>
    </nav>

    <div class="slider-backramp">
        <div class="slide-item active" style="background-image: url('<?= $img1 ?>');"></div>
        <div class="slide-item" style="background-image: url('<?= $img2 ?>');"></div>
        <div class="slide-item" style="background-image: url('<?= $img3 ?>');"></div>
        <div class="brand-master-title">
            <h1><?= $projectName ?></h1>
            <span class="sub-line">COMMUNITY PLAYER</span>
        </div>
    </div>

    <div class="section-separator"></div>

    <main class="container-fluid px-lg-5" style="max-width: 1750px; margin-top: 80px;">
        <div class="row g-5">
            <aside class="col-xl-3">
                <?= $this->getMenu(1, '<div class="hytale-card"><div class="snake-top"></div><div class="snake-bottom"></div><div class="card-header">%s</div><div class="p-4 ilch_user_login">%c</div></div>') ?>
            </aside>
            <div class="col-xl-6">
                <div class="hytale-card p-4 p-md-5">
                    <div class="snake-top"></div><div class="snake-bottom"></div>
                    <div class="content-text"><?= $this->getContent() ?></div>
                </div>
            </div>
            <aside class="col-xl-3">
                <?= $this->getMenu(2, '<div class="hytale-card"><div class="snake-top"></div><div class="snake-bottom"></div><div class="card-header">%s</div><div class="p-4 ilch_user_login">%c</div></div>') ?>
            </aside>
        </div>
    </main>

    <footer class="master-footer">
        <div class="container text-center">
            <div class="footer-logo mb-4">
                <span style="color:#fff;">HYTALE</span> <span style="color:var(--accent);">GAMING</span>
            </div>
            <div class="footer-links mb-4">
                <a href="<?= $this->getUrl(['module' => 'contact']) ?>" class="mx-3">Kontakt</a>
                <a href="<?= $this->getUrl(['module' => 'imprint']) ?>" class="mx-3">Impressum</a>
                <a href="<?= $this->getUrl(['module' => 'privacy']) ?>" class="mx-3">Datenschutz</a>
            </div>
            <div class="copyright text-muted small">
                &copy; <?= date('Y') ?> <?= $projectName ?>. All rights reserved.<br>
                Powered by Ilch 2.0 & Design by rumpel
            </div>
            <a href="#top" class="mt-4 d-inline-block" style="color:var(--accent) !important;"><i class="fa-solid fa-chevron-up"></i> Back to Top</a>
        </div>
    </footer>

    <div id="loginPopup" onclick="this.style.display='none'" style="position: fixed; inset: 0; background: rgba(0,0,0,0.95); z-index: 10000; display: none; align-items: center; justify-content: center; backdrop-filter: blur(10px);">
        <div class="hytale-card" style="width: 450px; border: 2px solid var(--accent);" onclick="event.stopPropagation()">
            <div class="card-header">LOGIN <span class="float-end" style="cursor:pointer;" onclick="document.getElementById('loginPopup').style.display='none'">[X]</span></div>
            <div class="p-5 ilch_user_login"><?= $this->getBox('user', 'login') ?></div>
        </div>
    </div>

    <script src="<?= $layoutUrl ?>/js/jquery.min.js"></script>
    <script src="<?= $layoutUrl ?>/js/bootstrap.bundle.min.js"></script>
    <script src="<?= $layoutUrl ?>/js/aos.js"></script>
    <script>
        $(document).ready(function(){ 
            AOS.init({duration: 1200, once: true}); 

            // Slider Logic
            let items = $('.slide-item');
            let current = 0;
            if(items.length > 1) {
                setInterval(function() {
                    items.eq(current).removeClass('active');
                    current = (current + 1) % items.length;
                    items.eq(current).addClass('active');
                }, 7000); 
            }
        });
    </script>
    <?= $this->getFooter() ?>
</body>
</html>