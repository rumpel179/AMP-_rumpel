<?php

namespace Layouts\hytale_community\Config;

class Config extends \Ilch\Config\Install
{
    public $config = [
        'name' => 'Hytale Community Forum',
        'version' => '1.2.5',
        'author' => 'Rumpel',
        'desc' => 'High-End Gaming Layout f�r Ilch 2.0. Features: Glas-Optik-Module, Huawei-Glow-Effekte, animierte Snake-Trennlinien und ein dynamischer 3-Bilder-Slider.',
        'layouts' => [
            'index_full' => [
                ['module' => 'user', 'controller' => 'panel'],
                ['module' => 'forum'],
                ['module' => 'guestbook'],
                ['module' => 'contact'],
                ['module' => 'imprint'],
                ['module' => 'privacy'],
                ['module' => 'gallery'],
                ['module' => 'download'],
                ['module' => 'faq'],
                ['module' => 'calendar'],
                ['module' => 'event'],
                ['module' => 'linklist'],
                ['module' => 'voting'],
                ['module' => 'jobs']
            ]
        ],
        'settings' => [
            'project_name' => [
                'type' => 'text',
                'default' => 'HYTALE COMMUNITY',
                'description' => 'Haupttitel der Webseite (wird in der Navigation und gro� im Slider angezeigt).',
            ],
            'color' => [
                'type' => 'colorpicker',
                'default' => '#00f2ff',
                'description' => 'Zentrale Akzentfarbe f�r das gesamte Design (Glow, Trennlinien, Hover-Effekte).',
            ],
            'hida_height' => [
                'type' => 'text',
                'default' => '650',
                'description' => 'Einstellbare H�he des Slider-Kopfbereichs in Pixeln (Standard: 650).',
            ],
            'slider_img_1' => [
                'type' => 'mediaselection',
                'default' => 'application/layouts/hytale_community/img/header_bg.jpg',
                'description' => 'Erstes Hintergrundbild f�r den Slider-Wechsel.',
            ],
            'slider_img_2' => [
                'type' => 'mediaselection',
                'default' => 'application/layouts/hytale_community/img/header_bg.jpg',
                'description' => 'Zweites Hintergrundbild f�r den Slider-Wechsel.',
            ],
            'slider_img_3' => [
                'type' => 'mediaselection',
                'default' => 'application/layouts/hytale_community/img/header_bg.jpg',
                'description' => 'Drittes Hintergrundbild f�r den Slider-Wechsel.',
            ],
        ]
    ];

    public function getUpdate($installedVersion)
    {
        return true;
    }
}